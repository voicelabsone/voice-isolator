from flask import Flask, request, jsonify
import os
from spleeter.separator import Separator

app = Flask(__name__)
separator = Separator('spleeter:2stems')

os.makedirs('uploads', exist_ok=True)
os.makedirs('outputs', exist_ok=True)

@app.route('/split', methods=['POST'])
def split_audio():
    if 'file' not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    audio = request.files['file']
    input_path = os.path.join('uploads', audio.filename)
    audio.save(input_path)

    output_path = os.path.join('outputs', audio.filename.split('.')[0])
    separator.separate_to_file(input_path, 'outputs')

    return jsonify({"message": "Separation done", "output_dir": output_path})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=os.environ.get('PORT', 5000))
